from readfile import ReadFile
#import readfile class
class Sudoku:
    #class to actually interact with the sudoku list and solve it.
    def __init__(self,filename):
        read_file = ReadFile(filename)
        #create instance of ReadFile object
        self.sudoku_board = read_file.import_board()
        #store contents of file in list named sudoko_board

    def check_valid(self,row,col,num):
        #method to check whether or not a certain number can be placed in a certain coordinate
        if self.sudoku_board[row][col] != "_":
            #if given coordinate is not "_" then return false
            return False
        if str(num) in self.sudoku_board[row]:
            #check if given number is already in the row, if so return false
            return False
        
        column_list = [elem[col] for elem in self.sudoku_board]
        #create list that stores all numbers of the given column 

        if str(num) in column_list:
            #if the given number is in the given column, return false
            return False

        self.box = self.create_box(row,col)
        #call create_box method to create a list that stores all the numbers in the given coordinates' box.
        if str(num) in self.box:
            #if the given number is in the box, return false
            return False

        #if function reaches here, then the given number is able to be places in the coordinate and thus we return true
        return True
    
    def create_box(self,row,col):
        #method to create a list that stores all numbers in given coordinates box
        self.box = []
        #initialize or empty list of nums in box
        if row<=2:
            #if given row is less than 3, narrow down search
            if col <= 2:
                #if col is less than 3, the box is from rows 0 to 2 and cols 0 to 2
                for row in range(0,3):
                    for col in range(0,3):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            elif col <= 5:
                #else if col is less than 6, the box is from rows 0 to 2 and cols 3 to 5
                for row in range(0,3):
                    for col in range(3,6):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            else:
                #else, the box is from rows 0 to 2 and cols 6 to 8
                for row in range(0,3):
                    for col in range(6,9):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
        elif row<=5:
            #else if narrow search down to rows 3 to 5
            if col <= 2:
                #if col is less than 3, the box is from rows 3 to 5 and cols 0 to 2
                for row in range(3,6):
                    for col in range(0,3):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            elif col <= 5:
                #else if col is less than 6, the box is from rows 3 to 5 and cols 3 to 5
                for row in range(3,6):
                    for col in range(3,6):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            else:
                #else, the box is from rows 3 to 5 and cols 6 to 8
                for row in range(3,6):
                    for col in range(6,9):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
        else:
            #else rows must be from 6 to 8
            if col <= 2:
                #if col is less than 3, the box is from rows 6 to 8 and cols 0 to 2
                for row in range(6,9):
                    for col in range(0,3):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            elif col <= 5:
                #else if col is less than 6, the box is from rows 6 to 8 and cols 3 to 5
                for row in range(6,9):
                    for col in range(3,6):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list
            else:
                 #else, the box is from rows 6 to 8 and cols 6 to 8
                for row in range(6,9):
                    for col in range(6,9):
                        self.box.append(self.sudoku_board[row][col])
                        #now that we have found the box, append given box to self.box list

        return self.box
        #return self.box so check_valid() can use it

        

    def solve(self):
        #recursive function that will DFS algorithm to solve sudoku board
        if self.check_solved():
            #base case- check if the board is solved, if so return True
            return True

        row,col = self.find_empty()
        #use find_empty func to get row,col that has "_"
        for i in range(1,10):
            #iterate through numbers 1 through 9
            if self.check_valid(row,col,i):
                #check if i is able to be placed in given coordinate
                self.sudoku_board[row][col] = str(i)
                #if it is valid, place i in coordinate
                if self.solve():
                    #call function recursively and keep going on from previous point and check if board is eventually solved
                    return True
                    #if solved, return True and end func
            #if board not solved, backtrack and mark board with "_" and try next number in for loop
            self.sudoku_board[row][col] = "_"
        #return False, indicating board is not solvable.
        return False

        

    def check_solved(self):
        #method to see if the sudoku board is solved or not
        for row in self.sudoku_board:
            #iterate through each row in board
            if "_" in row:
                #if there is a "_" anywhere, it means board is not solved
                return False
                #return False
        #if func reaches here, it means board is solved, so return True
        return True

    def find_empty(self):
        #func to find next empty point in board
        for row in range(9):
            #iterate through rows of board
            for col in range(9):
                #iterate through columns of board
                if self.sudoku_board[row][col] == "_":
                    #if board has "_", return index
                    return row,col
        #else return None
        return None
    
    def print_board(self):
        #function to print the board to the terminal
        for row in self.sudoku_board:
            #iterate through row in board
            print(row)
            #print the row









