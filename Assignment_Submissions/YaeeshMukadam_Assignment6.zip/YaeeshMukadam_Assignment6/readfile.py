class ReadFile:
    #create class to read in files and return 2d list containing unsolved sudoku
    def __init__(self,filename):
        self.filename = filename
        #create filename attribute
        input_file = open(self.filename,"r")
        #open file
        self.sudoku_board = []
        #initialize list to store file contents
        for line in input_file:
            self.sudoku_board.append(line.split())
            #append list of each line to the sudoku board list

    def import_board(self):
        #method to import board from file to other classes
        return self.sudoku_board

