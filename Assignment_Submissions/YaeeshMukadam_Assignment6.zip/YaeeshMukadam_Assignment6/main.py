'''
Yaeesh Mukadam
EECS 210 Assignment 6
Description: Python program that uses depth first search to solve sudoku.
Date: Nov 9, 2023
Inputs: 5 puzzle text files containing unsolved sudokus.
Output: printed statements of file names, file contents, and solved sudokus for given files.
Collaborators: None
'''
from sudoku import Sudoku
#import sudoku class

def main():
    #main function which print all 5 file names, file contents, and the solved sudokus if posssible
    test_files = ["puzzle1.txt", "puzzle2.txt", "puzzle3.txt","puzzle4.txt","puzzle5.txt"]
    #create list of given input files to iterate through
    for file in test_files:
        #iterate through input files
        my_sudoku = Sudoku(file)
        #create instance of Sudoku class
        print(f'Solving {file}...')
        #print solving given file
        print("Unsolved puzzle:")
        #print the contents of the text_file
        my_sudoku.print_board()
        print("")
        #formatting
        if my_sudoku.solve():
            #if the sudoku is solvable, print the given solved board
            print("Solved Sudoku:")
            my_sudoku.print_board()
        else:
            #else print that it is not possible
            print("Sudoku is unsolvable.")
        print("")
        print("-"*50)
        #formatting

if __name__ == "__main__":
    main()
    #call main function to run program