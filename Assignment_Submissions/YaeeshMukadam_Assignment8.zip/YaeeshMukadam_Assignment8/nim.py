import random

class Nim:
    def __init__(self, pile1,pile2,pile3):
        self.pile1 = pile1
        self.pile2 = pile2
        self.pile3 = pile3

